<?php
/***************************************************************************************
 *                       			kesimpulan_model.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	kesimpulan_model.php
 *      Created:   		2013 - 15.37.25 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 class Kesimpulan_model extends MY_Model
 {
 	public $_table = 'kesimpulan';
 	public $primary_key = 'kesimpulan_id';
 	
 }
 
 /* End of File: kesimpulan_model.php */
/* Location: ../www/modules/kesimpulan_model.php */ 

?>

