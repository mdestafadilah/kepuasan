<?php
/***************************************************************************************
 *                       			mu.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	mu.php
 *      Created:   		2013 - 14.16.31 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Mu extends MX_Controller
 {
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->library(array('pagination','ion_auth','session','form_validation'));
		$this->load->model(array('user/user_model','dimensi/dimensi_model','soal/soal_model','mu_model'));
  	}
  	
 	function index()
 	{
 		$this->_manage();
 	}
 	
 	function update($id = null)
 	{
 		$mu = $this->mu_model->get($id); // an object of soal
 		$soal = $this->soal_model->get_all();
 		$konsumen = $this->user_model->get_all();
 		$dimensi = $this->dimensi_model->get_all();
 		$soalDimensi = $this->mu_model
 							->with('banksoal')
						 	->with('users')
						 	->with('dimensi')
 							->get_all();
 		
 		$this->form_validation->set_rules('pertanyaan', 'Pertanyaan', 'required');
 		$this->form_validation->set_rules('username', 'Nama Konsumen', 'required');
 		$this->form_validation->set_rules('dimensi', 'Dimensi', 'required');
 		$this->form_validation->set_rules('MuFire', 'Nilai Total', 'required');
 		$this->form_validation->set_rules('MuKecewa', 'Nilai Kecewa', 'required');
 		$this->form_validation->set_rules('MuBiasa', 'Nilai Biasa', 'required');
 		$this->form_validation->set_rules('MuPuas', 'Nilai Puas', 'required');
 		
 		// cek hasil ketik
 		if (isset($_POST) && !empty($_POST))
 		{
 			$data = array(
 					'pertanyaan' => $this->input->post('pertanyaan'),
 					'username' => $this->input->post('faktor'),
 					'dimensi' => $this->input->post('dimensi'),
 					'MuFire' => $this->input->post('MuFire'),
 					'MuKecewa' => $this->input->post('MuKecewa'),
 					'MuBiasa' => $this->input->post('MuBiasa'),
 					'MuPuas' => $this->input->post('MuPuas'),
 			);
 		
 			// jika bedul
 			if ($this->form_validation->run() == TRUE &&
 					$this->mu_model->update($mu->id, $data))
 			{
 				$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Mu sudah terupdate! </div>");
 				redirect('mu/index', 'refresh');
 			}
 		}
 		
 		// Populate
 		$data['single'] = $mu;
 		$data['dimensi'] = $dimensi;
 		$data['banksoal'] = $soal;
 		$data['konsumen'] = $konsumen;
 			
 		
 		$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'.validation_errors().'</div>' : $this->session->flashdata('message'));
 		
 		$data['MuKecewa'] = array(
 				'name'  => 'MuKecewa',
 				'id'    => 'MuKecewa',
 				'type'  => 'text',
 				'value' => $this->form_validation->set_value('MuKecewa', $mu->MuKecewa),
 		);
 		$data['MuBiasa'] = array(
 				'name'  => 'MuBiasa',
 				'id'    => 'MuBiasa',
 				'type'  => 'text',
 				'value' => $this->form_validation->set_value('MuBiasa', $mu->MuBiasa),
 		);
 		
 		$data['MuPuas'] = array(
 				'name'  => 'MuPuas',
 				'id'    => 'MuPuas',
 				'type'  => 'text',
 				'value' => $this->form_validation->set_value('MuPuas', $mu->MuPuas),
 		);
 		
 		$data['MuFire'] = array(
 				'name'  => 'MuFire',
 				'id'    => 'MuFire',
 				'type'  => 'text',
 				'value' => $this->form_validation->set_value('MuFire', $mu->MuFire),
 		);
 		// render template
 		$data['welcome'] = ucfirst($this->session->userdata('email'));
 		$data['title'] = "Modul Fuzzy Keanggotaan - Ubah Nilai Keanggotaan";
 		$data['module'] = "mu"; // module
 		$data['mu'] = "mu"; // controller
 		$data['view'] = "mu_edit"; // view
 		
 		if($this->ion_auth->is_admin()) {
 			echo Modules::run('template/admin',$data);
 			}
 		if($this->ion_auth->in_group('manajer')) {
 			echo Modules::run('template/manajer', $data);
 			}
 			
 	}
 	
 	function delete($id)
 	{
 		if ($this->ion_auth->is_admin()
 							&& $this->mu_model->delete($id))
 		{
 			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Mu berhasil dihapus!</div>");
 			redirect('mu/index');
 		}
 	}
 	
 	function _manage()
 	{
 		
 		$this->load->library('pagination');
 		$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
 		
 		$uri_segment = 3;
 		$data['offset'] = $this->uri->segment($uri_segment);
 		
 		$config['base_url'] = base_url().'mu/index/';
 		$config['total_rows'] = $this->mu_model->count_all();
 		$config['per_page'] = 50;
 		$config['next_link'] = '<li>Selanjutnya</li>';
 		$config['prev_link'] = '<li>Sebelumnya</li>';
 		$config['cur_tag_open'] = '<li class="active"><a href="#">..</a> Halaman Ke -';
 		$config['cur_tag_close'] = '</li>';
 		
 		$this->pagination->initialize($config);
 		$data['paging'] = $this->pagination->create_links();
 		
 		$data['limit'] = $config['per_page'];
 		
 			
 		$data['alls'] = $this->mu_model
						 		->with('banksoal')
						 		->with('users')
						 		->with('dimensi')
						 		->order_by('user_id')
						 		->get_all();
 			
 			
 		// Template
 		$data['welcome'] = ucfirst($this->session->userdata('email'));
 		$data['title']  = "Module Mu - Data All";
 		$data['mu']  = "mu"; // Controller
 		$data['view']   = "mu_view"; // View
 		$data['module'] = "mu"; // Controller
 			
 		if($this->ion_auth->is_admin()) {
 			echo Modules::run('template/admin',$data);
 			}
 		if($this->ion_auth->in_group('manajer')) {
 			echo Modules::run('template/manajer', $data);
 			}
 	}
 	
 	function search()
 	{
 		echo "Still development";
 	}
 }
 
 
 /* End of File: mu.php */
/* Location: ../www/modules/mu.php */ 