<?php
/***************************************************************************************
 *                       			dimensi.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	dimensi.php
 *      Created:   		2013 - 16.38.31 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 
 
 /* End of File: dimensi.php */
/* Location: ../www/modules/dimensi.php */ 