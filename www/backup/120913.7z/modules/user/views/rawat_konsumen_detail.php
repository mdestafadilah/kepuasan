<div class="row-fluid">
	<div class="span12">
		<h3 class="heading">Detail Informasi Data Pasangan</h3>
		<div class="tabbable tabs-left">
			<ul class="nav nav-tabs">
				<li class="active"><a href="#tab_l1" data-toggle="tab">Client Information</a></li>
				<li><a href="#tab_l2" data-toggle="tab">Elderly Information</a></li>
				<li><a href="#tab_l3" data-toggle="tab">Questioner Information</a></li>

			</ul>
			<div class="tab-content">
				<div class="tab-pane active" id="tab_l1">
					<p>
						Still <em>CLIENT</em>
					</p>
				</div>
				<div class="tab-pane" id="tab_l2">
					<p>
						Still <em>ELDERLY!!</em>
					</p>
				</div>
				<div class="tab-pane" id="tab_l3">
					<p>
						Still <em>Development!!</em>
					</p>
				</div>
			</div>
		</div>
	</div>
	</div>