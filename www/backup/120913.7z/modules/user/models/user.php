<?php
/***************************************************************************************
 *                       			user.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	user.php
 *      Created:   		2013 - 11.06.47 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class User extends My_Model
 {
 	public $_table = array('Users','Groups');
 	
 	function __construct()
 	{
 		parent::__construct();
 		//$this->table = 'konsumen';
 		
 	}
 	
 	function get($id)
 	{
 		
 	}
 	
 	
 	
 	
 	
 	
 }
 
 
 /* End of File: user.php */
/* Location: ../www/modules/user.php */ 