<?php
/***************************************************************************************
 *                       			kesimpulan.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	kesimpulan.php
 *      Created:   		2013 - 15.37.07 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Kesimpulan extends MX_Controller 
 {
 	function __construct()
 	{
 		parent::__construct();
 		// IONAuth
 		$this->load->library(array('ion_auth','session','form_validation'));
 		$this->load->helper('url');
 		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
 		// Model
 		$this->load->model(array(
 					'kesimpulan/kesimpulan_model',
 					'dimensi/dimensi_model'
 				));

 	}
 	
 	function index()
 	{
 		if ( $this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer')){ $this->_manage(); }
 		if ( $this->ion_auth->in_group('perawat')) { $this->akhir(); }
 		if ( $this->ion_auth->in_group('manajer')) { $this->report(); }
 	}
 	
 	function _manage()
 	{
 	// paging
 		$this->load->library('pagination');
 		$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
 		
 		$uri_segment = 3	;
 		$data['offset'] = $this->uri->segment($uri_segment);
 		
 		$config['base_url'] = base_url().'kesimpulan/index/';
 		$config['total_rows'] = $this->kesimpulan_model->count_all();
 		$config['per_page'] = 3;
 		$config['next_link'] = '<li>Selanjutnya</li>';
 		$config['prev_link'] = '<li>Sebelumnya</li>';
 		$config['cur_tag_open'] = '<li class="active"><a href="#">..</a> Halaman Ke -';
 		$config['cur_tag_close'] = '</li>';
 		
 		$this->pagination->initialize($config);
 		$data['paging'] = $this->pagination->create_links();
 		
 		$data['limit'] = $config['per_page'];
 		
 		// all soal as object as object :)
 		$data['results'] = $this->kesimpulan_model
 								->as_array()
						 		->limit($data['limit'], $data['offset'])
						 		->get_all();
 			
 		// render a template
 		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 		$data['title'] 		= "Modul Kesimpulan - Daftar Kesimpulan";
 		$data['module'] 	= "kesimpulan"; // module
 		$data['kesimpulan'] = "kesimpulan"; // controller
 		$data['view'] 		= "kesimpulan_view"; // view
 			
 		if($this->ion_auth->is_admin()) {
 			echo Modules::run('template/admin',$data);
 		}
 		if($this->ion_auth->in_group('manajer')) {
 			echo Modules::run('template/manajer', $data);
 		}
 	}
 	
 	// belum bekerja
 	function add()
 	{
 		// Admin dan Manajer can do this
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 			// buat aturan dulu
 			$this->form_validation->set_rules('kesimpulan','Kesimpulan','required');
 			$this->form_validation->set_rules('dimensi','Dimensi','required');
 		}
 			
 		if ($this->form_validation->run() == true)
 		{
 			$data = array(
 					'kesimpulan' 	=> $this->input->post('kesimpulan'),
 					'dimensi' 		=> (implode(",",$this->input->post('dimensi'))),
 			);
 		}
 			
 		if ($this->form_validation->run() == true
 				&& $this->kesimpulan_model->insert($data))
 		{
 			//dump($_POST); exit;
 			$this->session->set_flashdata('message', "<div class=\"alert alert-success\"> <a class=\"close\" data-dismiss=\"alert\">X</a>Kesimpulan Berhasil Ditambahkan </div>");
 			redirect(base_url().'kesimpulan');
 		}
 		else
 		{
 			// populate data
 			$data['message'] = (validation_errors() ? '<div class="alert alert-error"> <a class="close" data-dismiss="alert">X</a>'. validation_errors().'</div>' : $this->session->flashdata('message'));
 			
 			$data['kesimpulan'] = array(
 					'name'  => 'kesimpulan',
 					'id'    => 'kesimpulan',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('kesimpulan'),
 			);
 				
 			// render template
 			$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 			$data['title'] 		= "Modul Kesimpulan - Tambah Kesimpulan";
 			$data['module'] 	= "kesimpulan"; // module
 			$data['kesimpulan']	= "kesimpulan"; // controller
 			$data['view'] 		= "kesimpulan_form"; // view
 		
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 		}
 	}
 	
 	// belum bekerja
 	function update($kesimpulan_id)
 	{
 		if (!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
 		{
 			echo 'You don\'t have an access';
 			echo br(2);
 			echo anchor('soal/index', 'Kembali');
 		}
 			
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 				
 			$kesimpulan = $this->kesimpulan_model->get($kesimpulan_id); // an object of soal
 		
 			$this->form_validation->set_rules('kesimpulan', 'Kesimpulan', 'required');
 			$this->form_validation->set_rules('dimensi', 'Dimensi', 'required');
 		
 			// cek hasil ketik
 			if (isset($_POST) && !empty($_POST))
 			{
 				$data = array(
 						'kesimpulan' => $this->input->post('kesimpulan'),
 						'dimensi' => $this->input->post('dimensi'),
 				);
 		
 				// jika bedul
 				if ($this->form_validation->run() == TRUE &&
 						$this->kesimpulan_model->update($kesimpulan->kesimpulan_id, $data))
 				{
 					$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Kesimpulan sudah terupdate! </div>");
 					redirect('kesimpulan/index', 'refresh');
 				}
 			}
 		
 			// Populate
 			$data['single'] = $kesimpulan;
 		
 			$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'.validation_errors().'</div>' : $this->session->flashdata('message'));
 	
 			$data['kesimpulan'] = array(
 					'name'  => 'kesimpulan',
 					'id'    => 'kesimpulan',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('kesimpulan', $kesimpulan->kesimpulan),
 			);
 			
 			$data['dimensi'] = array(
 					'name'  => 'dimensi',
 					'id'    => 'dimensi',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('dimensi', $kesimpulan->dimensi),
 			);
 		
 			// render template
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] = "Modul Kesimpulan - Ubah Data Kesimpulan";
 			$data['module'] = "kesimpulan"; // module
 			$data['kesimpulan'] = "kesimpulan"; // controller
 			$data['view'] = "kesimpulan_form"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 		}
 	}
 	
 	function delete($kesimpulan_id)
 	{
 		if (!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
 		{
 			echo 'You don\'t have an access';
 			echo br(2);
 			echo anchor('kesimpulan/index','Kembali');
 		}
 			
 		/*
 		 * Admin done
 		*/
 		elseif ($this->ion_auth->is_admin()
 				&& $this->kesimpulan_model->delete($kesimpulan_id))
 		{
 			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Kesimpulan berhasil dihapus!</div>");
 			redirect('kesimpulan/index');
 		}
 		/*
 		 * Manajer done
 		*/
 		elseif ($this->ion_auth->in_group('manajer')
 				&& $this->kesimpulan_model->delete($kesimpulan_id))
 		{
 			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Kesimpulan berhasil dihapus!</div>");
 		
 			redirect('kesimpulan/index');
 		}
 	}
 	
 	function do_publish($kesimpulan_id)
 	{
 		// cek harus manajer yang lakukan fungsi ini
 		if (!$this->ion_auth->logged_in() || !$this->ion_auth->in_group('manajer'))
 		{
 			echo "You don\'t have an access";
 			echo br(2);
 			echo anchor("kesimpulan/index", "Kembali");
 		}
 		else
 		{
 			$this->db->where("kesimpulan_id", $kesimpulan_id);
 			$this->db->set("publish", 1);
 			$this->db->update("kesimpulan");
 			$this->session->set_flashdata('message', "Kesimpulan Sudah aktif");
 			redirect("kesimpulan/index");
 		}
 	}
 	
 	function do_unpublish()
 	{
 		// cek harus manajer yang lakukan fungsi ini
 		if (!$this->ion_auth->logged_in() || !$this->ion_auth->in_group('manajer'))
 		{
 			echo "You don\'t have an access";
 			echo br(2);
 			echo anchor("kesimpulan/index", "Kembali");
 		}
 		else
 		{
 			$this->db->where("kesimpulan_id", $kesimpulan_id);
 			$this->db->set("publish", 0);
 			$this->db->update("kesimpulan");
 			$this->session->set_flashdata('message', "Kesimpulan Sudah tidak aktif");
 			redirect("kesimpulan/index");
 		}
 	}
 	
 	function akhir()
 	{
 		echo "Final untuk perawat";
 	}
 	
 	function report()
 	{
 		echo "Report hereeee";
 	}
 }
 
 
 /* End of File: kesimpulan.php */
/* Location: ../www/modules/kesimpulan.php */ 