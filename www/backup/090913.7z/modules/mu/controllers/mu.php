<?php
/***************************************************************************************
 *                       			mu.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	mu.php
 *      Created:   		2013 - 14.16.31 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Mu extends MX_Controller
 {
 	function __construct()
 	{
 		parent::__construct();
 	}
 	
 	function index()
 	{
 		
 	}
 	
 	function delete()
 	{
 		
 	}
 	
 	function _manage()
 	{
 		
 	}
 }
 
 
 /* End of File: mu.php */
/* Location: ../www/modules/mu.php */ 