<?php echo form_open_multipart('restore/upload'); ?>
			<input type="file" name="userfile" class="input-read-only" />
			<input type="submit" value="Restore Data" class="btn-kirim-login" />
<?php echo form_close(); ?>  