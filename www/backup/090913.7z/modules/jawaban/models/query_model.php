<?php
/**
* File: noname.php
* Short description for file
*
* Long description for file (if any)...
*
* LICENSE: Some license information
*
* @date       17-07-2013 12:48
* @category   AksiIDE
* @package    AksiIDE
* @subpackage
* @copyright  Copyright (c) 2013-endless AksiIDE
* @license
* @version    $version$
* @link       http://aksiide.com
* @since
*/

class Query_model extends MY_Model
{
	public $_table = 'jawaban';
 	public $primary_key = "jawaban_id";

 	public $belongs_to = array( 'banksoal' );
  public $has_many = array( 'users' );
}



