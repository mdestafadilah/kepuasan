<?php
/***************************************************************************************
 *                       			hasil.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	hasil.php
 *      Created:   		2013 - 10.53.22 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 class Hasil extends MX_Controller
 {
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->model(array(
 					'jawaban/jawaban_model',
 					'user/user_model',
 					'soal/soal_model',
 				));
 	}
 	
 	function debuk()
 	{
 	
		dump($data['pasangan']); exit;
 	}
 	
 	function index()
 	{
 		
		$id = $this->session->userdata('user_id');
 		 		
		$data['pasangan'] = $this->db->query("
												SELECT
												#konsumen
										 		userkonsumen.username AS `nama_konsumen`,
												#perawat
										 		userperawat.username AS `nama_perawat`												FROM	
										 		rawatkonsumen AS rawat
										 		INNER JOIN users AS userkonsumen ON rawat.konsumen_id = userkonsumen.id
										 		INNER JOIN users AS userperawat ON rawat.perawat_id = userperawat.id
												WHERE
												userperawat.id = $id				
												")->row();
		
 		// Ambil dengan Faktor dirasakan
 		$data['dirasakan'] = $this->db->query("SELECT
 				s.pertanyaan,
 				s.faktor,
 				u.username,
 				a.variabel AS Pilihan,
 				a.nilai AS nilai_max,
 				FROM
 				jawaban AS j
 				INNER JOIN banksoal AS s ON j.banksoal_id = s.banksoal_id
 				INNER JOIN users AS u ON j.user_id = u.id
 				INNER JOIN aturan AS a ON j.aturan_id = a.aturan_id
 				WHERE
 				u.id = $id AND s.faktor = 'dirasakan'
 				GROUP BY
 				j.jawaban_id
 				ORDER BY
 				u.username ASC")->result();
 		
 				// Ambil dengan Faktor diharapakan
 		$data['diharapkan'] = $this->db->query("SELECT
 				s.pertanyaan,
 				s.faktor,
 				u.username,
 				a.variabel AS Pilihan,
 				a.nilai AS nilai_max,
 				FROM
 				jawaban AS j
 				INNER JOIN banksoal AS s ON j.banksoal_id = s.banksoal_id
 				INNER JOIN users AS u ON j.user_id = u.id
 				INNER JOIN aturan AS a ON j.aturan_id = a.aturan_id
 				WHERE
 				u.id = $id AND s.faktor = 'diharapkan'
 				GROUP BY
 				j.jawaban_id
 				ORDER BY
 				u.username ASC")->result();
 		
 		
 		$data['welcome'] = ucfirst($this->session->userdata('email'));
 		$data['title'] 	 = "Module Pengguna Sistem";
 		$data['jawaban'] = "hasil"; 		// Controller
 		$data['view'] 	 = "hasil_perawat"; 	// View
 		$data['module']  = "jawaban"; 		// Controller
 		
 		echo Modules::run('template/perawat',$data);
 		
 	}
 	
 	function detail()
 	{
 		echo "detail";
 	}
 }
 
 /* End of File: hasil.php */
/* Location: ../www/modules/hasil.php */ 