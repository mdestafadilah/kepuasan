<?php
/***************************************************************************************
 *                       			aturan.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	aturan.php
 *      Created:   		2013 - 13.56.14 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Aturan extends MX_Controller
 {
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->model(array('aturan/aturan_model'));
 		//$this->load->library(array('highcharts','ion_auth','session','form_validation'));
 		$this->load->library('highcharts'); 			
 	}
 	
 	function debuk()
 	{
 		$data = $this->db->query("SELECT
 				faktor as `jenis_soal`,
 				COUNT(faktor) as `Jumlah`
 				FROM
 				banksoal
 				GROUP BY faktor
 				")->result_array();
 		echo "<pre>";
 		print_r($data);
 		echo "<hr />";
 		foreach($data as $dt)
 		{
 			echo $dt['jenis_soal'];
 		}
 	}
 	 	
 	function index()
 	{
 		/* $result = $this->aturan_model->get_all();
 		
 		$dat1['x_labels'] = 'variabel';
 		$dat1['y_labels'] = 'aturan_id';
 		$dat1['series'] = array('min','max');
 		$dat1['data'] = $result;
 		
 		 			
 		$this->highcharts
 				->set_type('bar')
 				
 				->from_result($dat1)
 				->add(); */
 		
 		$result = $this->db->query("SELECT
					 				faktor as `jenis_soal`,
					 				COUNT(faktor) as `jumlah`
					 				FROM
					 				banksoal
					 				GROUP BY faktor
					 				")->result_array();
 		
 		$this->highcharts
 			 ->set_type('column')
 			 ->set_title('Total Soal','Soal Terjawab Oleh Konsumen')
 			 
 			 ->from_result($dat1)
 			 ->add();
 		
 		$data['charts'] = $this->highcharts->render();
 		
 		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 		$data['title'] 	 	= "Module Jawaban - Hasil Jawaban";
 		$data['grafik']    = "grafik"; // Controller
 		$data['view'] 		= "grafik_aturan"; // View
 		$data['module'] 	= "grafik"; // Controller
 		
 		echo Modules::run('template/direktur',$data);
 	}
 	
 	function _data()
 	{
 		$data['jenkel']['data'];
 	}
 }
 
 
 /* End of File: aturan.php */
/* Location: ../www/modules/aturan.php */ 