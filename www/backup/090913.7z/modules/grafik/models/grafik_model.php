<?php
/***************************************************************************************
 *                       			grafik_model.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	grafik_model.php
 *      Created:   		2013 - 19.53.55 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Grafik_model extends MY_Model
 {
 	public $_table = '';
 	public $primary_key = '';
 }
 
 
 /* End of File: grafik_model.php */
/* Location: ../www/modules/grafik_model.php */ 