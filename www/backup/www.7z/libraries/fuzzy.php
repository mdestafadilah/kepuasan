<?php
/***************************************************************************************
 *                       			fuzzy.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	fuzzy.php
 *      Created:   		2013 - 22.09.21 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class fuzzy {
 	public function dan()
 	{
 		
 	}
 	
 	public function atau()
 	{
 		
 	}
 	
 	public function jika()
 	{
 		
 	}
 }
 
 
 /* End of File: tahani.php */
/* Location: ../www/modules/fuzzy.php */ 