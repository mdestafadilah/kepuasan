<?php
/***************************************************************************************
 *                       			user.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	user.php
 *      Created:   		2013 - 11.06.47 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class User extends CI_Model
 {
 	function __construct()
 	{
 		parent::__construct();
 		
 	}
 	
 	
 }
 
 
 /* End of File: user.php */
/* Location: ../www/modules/user.php */ 