<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Role
$route['user/admin'] = 'admin';
$route['user/konsumen'] = 'konsumen';
$route['user/perawat'] = 'perawat';
$route['user/(.*)'] = 'user/$1';

$route['404_override'] = 'errors/error_404';

// $route['([a-zA-Z_-]+)'] = 'user/admin/$1';

// $route['^([a-z]{2})/(.*)'] = '$2';
// $route['^([a-z]{2})'] = $route['default_controller'];
//
// $route['(:any)/page/test'] = "$1/news/page/1";
// $route['(:any)/page/test'] = "news/page/1";
// http://stackoverflow.com/questions/9694419/how-can-i-solve-routing-in-hmvc



/* End of file routes.php */
/* Location: ./application/modules/user/config/routes.php */
