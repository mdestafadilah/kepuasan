<div class="row-fluid">
						<div class="span12">
							<h3 class="heading">User Profile (static)</h3>
							<div class="row-fluid">
								<div class="span12">
									<div class="vcard">
										<img class="thumbnail" src="http://www.placehold.it/80x80/EFEFEF/AAAAAA" alt="" />
										<ul>
											<li class="v-heading">
												User info
											</li>
											<li>
												<span class="item-key">Full name</span>
												<div class="vcard-item">John Smith</div>
											</li>
											<li>
												<span class="item-key">Username</span>
												<div class="vcard-item">jsmith</div>
											</li>
											<li>
												<span class="item-key">Email</span>
												<div class="vcard-item">johnSmith@example.com</div>
											</li>
											<li>
												<span class="item-key">Gender</span>
												<div class="vcard-item">Male</div>
											</li>
											<li>
												<span class="item-key">Languages:</span>
												<div class="vcard-item">
													<ul class="list_a">
														<li>English</li>
														<li>French</li>
														<li>German</li>
													</ul>
												</div>
											</li>
											<li>
												<span class="item-key">Signature</span>
												<div class="vcard-item">
													Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id quam orci, in ornare sapien. Nulla ultrices vestibulum erat a ullamcorper. Fusce eu nisl at nulla tempus posuere.
												</div>
											</li>
											<li class="v-heading">
												Recent activity <span>(latest 24 hours)</span>
											</li>
											<li>
												<ul class="unstyled sepH_b item-list">
													<li><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet...</a></li>
													<li><i class="splashy-document_letter_edit sepV_b"></i>John <a href="#">posted</a> new article <a href="#">Lorem ipsum dolor sit amet, consectetur...</a></li>
													<li><i class="splashy-image_cultured  sepV_b"></i>John added <a href="#">new_image,jpg</a></li>
													<li><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit </a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur </a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum, consectetur adipiscing elit</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit </a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur </a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing</a></li>
													<li class="item-list-more"><i class="splashy-comment sepV_b"></i>John <a href="#">commented</a> on <a href="#">Lorem ipsum, consectetur adipiscing elit</a></li>
												</ul>
												<a href="#" data-items="5" class="item-list-show btn btn-mini">Show 5 more...</a>
											</li>
											<li class="v-heading">
												User images
											</li>
											<li>
												<div class="sepH_a item-list clearfix">
													<img class="thumbnail sepV_a sepH_a" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
													<img class="thumbnail sepV_a sepH_a item-list-more" src="http://www.placehold.it/100x100/EFEFEF/AAAAAA" alt="" />
												</div>
												<a href="#" data-items="5" class="item-list-show btn btn-mini">Show 5 more...</a>
											</li>
										</ul>
									</div>
								</div>
							</div>	
						</div>
					</div>