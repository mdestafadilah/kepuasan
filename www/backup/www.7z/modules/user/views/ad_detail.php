<?php
/***************************************************************************************
 *                       			ad_detail.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	ad_detail.php
 *      Created:   		2013 - 17.43.10 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 
 
 /* End of File: ad_detail.php */
/* Location: ../www/modules/ad_detail.php */ 