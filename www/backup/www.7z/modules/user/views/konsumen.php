

<p>Login sebagai $user; </p>
<p><a href="<?php echo site_url('auth/logout');?>">Keluar</a></p>
