<?php
/***************************************************************************************
 *                       			admin.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	admin.php
 *      Created:   		2012 - 12.26.00 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
class Admin extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->helper(array('url', 'form'));
	}

	function index()
	{
		if ($this->ion_auth->is_admin())
		{
				
			//set the flash data error message if there is one
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			
			//list the users
			$data['users'] = $this->ion_auth->users()->result();
			foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
			
			//echo Modules::run('template/admin',$data);
			$this->load->view('user/admin',$data);
		}else{
			show_404();
		}	
	}
	
	function create_user()
	{
		echo 'others';
	}
	
}
 
 
 /* End of File: admin.php */
/* Location: ../www/modules/admin.php */ 