<?php
/***************************************************************************************
 *                       			history.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	history.php
 *      Created:   		2013 - 04.24.20 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class History extends MX_Controller
 {
 	function __construct(){
 		parent::__construct();
 	}
 	
 	
 }
 
 
 /* End of File: history.php */
/* Location: ../www/modules/history.php */ 