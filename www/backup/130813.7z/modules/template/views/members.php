<html>
	<head>
		<title>Default Members!</title>
	</head>
	<body>
		<h3>Status anda Hanya Member Biasa dan Belum di Aktifkan ke dalam Sistem!</h3>
		<h3>Tolong Hubungi PT. Narendra Krida, Jika anda sebagai Perawat atau Client agar bisa 
			mengakses sistem ini.
		</h3>
		<h2>Contact: 083898973731</h2>
	</body>
</html>