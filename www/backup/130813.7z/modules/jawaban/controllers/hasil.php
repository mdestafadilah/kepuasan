<?php
/***************************************************************************************
 *                       			hasil.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	hasil.php
 *      Created:   		2013 - 10.53.22 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 class Hasil extends MX_Controller
 {
 	function __construct()
 	{
 		parent::__construct();
 		$this->load->model(array(
 					'jawaban/jawaban_model',
 					'user/user_model',
 					'soal/soal_model',
 				));
 	}
 	
 	function debuk()
 	{
 		$data = $this->jawaban_model->get_all();
 		dump($data); exit;
 	}
 	
 	function index()
 	{
 		$data['welcome'] = ucfirst($this->session->userdata('email'));
 		$data['title'] 	 = "Module Pengguna Sistem";
 		$data['jawaban'] = "hasil"; 		// Controller
 		$data['view'] 	 = "hasil_perawat"; 	// View
 		$data['module']  = "jawaban"; 		// Controller
 		
 		echo Modules::run('template/perawat',$data);
 		
 	}
 	
 	function detail()
 	{
 		
 	}
 }
 
 /* End of File: hasil.php */
/* Location: ../www/modules/hasil.php */ 