<?php
/***************************************************************************************
 *                       			jawaban.php
***************************************************************************************
*      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
*      Website:    	http://www.twitter.com/emang_dasar
*
*      File:          	jawaban.php
*      Created:   		2013 - 11.23.47 WIB
*      Copyright:  	(c) 2012 - desta
*                  	DON'T BE A DICK PUBLIC LICENSE
* 						Version 1, December 2009
*						Copyright (C) 2009 Philip Sturgeon
*
****************************************************************************************/
class Jawaban extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->library(array('pagination','ion_auth','session','form_validation'));
		$this->load->model(array('jawaban/jawaban_model','soal/soal_model','user/user_model','dimensi/dimensi_model'));

		// Enable Profiler
		// $this->output->enable_profiler(TRUE);
			
	}

	function debuk()
	{
				
		$data['jawa'] = $this->db->query("SELECT
											j.jawaban_id,j.created,	j.score,
											u.username,
											b.pertanyaan,
											d.nama,	
											b.faktor
											FROM
											jawaban AS j
											INNER JOIN banksoal AS b ON j.banksoal_id = b.banksoal_id
											INNER JOIN users AS u ON j.user_id = u.id
											INNER JOIN dimensi AS d ON b.dimensi_id = d.dimensi_id
											WHERE
											b.dimensi_id = 
													ORDER BY b.faktor ASC")->result();
		echo print_r($data['jawa']);
		echo "</pre>";
		dump($this->db->last_query());
		exit;
	}

	function index()
	{
		echo "Ok";
	}

	function _manage()
	{
		
	}

	function edit()
	{
			
	}

	/*
	 * Original from: http://tutorialzine.com/2012/01/question-of-the-day-codeigniter-php-mysql/
	* ----
	* Fungsi menambah jawaban
	* ----
	* @param $id
	* @access pelanggan
	*/
	function add($banksoal_id = -1)
	{
		$soal = $this->soal_model->as_array()->get_many_by(array('banksoal_id' => "$banksoal_id"));
			
		if (empty($soal))
		{
			echo "Soal belum di Inputkan";
		}

		// validasi inputan dropdon
		$this->form_validation->set_rules('pilihan', 'Pilihan', 'required');

		if ($this->form_validation->run() == FALSE)
		{
			// populate data
			$data = array(
					'banksoal'		=> $soal[0]['pertanyaan'],
					'banksoal_id'	=> $soal[0]['banksoal_id'],
					'user_id'		=> $this->session->userdata('user_id'),
					'next'			=> $next,
			);

			// set pesan
			$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'.validation_errors().'</div>' : $this->session->flashdata('message'));

			// render template
			$data['welcome'] 	= ucfirst($this->session->userdata('email'));
			$data['title'] 	 	= "Module Jawaban - Tambah Jawaban";
			$data['jawaban']    = "jawaban"; // Controller
			$data['view'] 		= "jawaban_pilihan"; // View
			$data['module'] 	= "jawaban"; // Controller

			echo Modules::run('template/konsumen',$data);
		}
		else
		{
			$date = now();
			//populate data
			$data = array(
					'user_id'		=> $this->session->userdata('user_id'),
					'banksoal_id'   => $soal[0]['banksoal_id'],
					'created'		=> $date,
					'score'			=> $this->input->post('pilihan'),
			);

			$this->jawaban_model->insert($data) && $this->jawaban_model->update_by(array());

			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Informasi berhasil ditambahkan!</div>");
			redirect('soal/tampil/'.$soal[0]['banksoal_id']);
		}
	}
	/*
	 * Get All in the table jawaban
	*/
	public function konsumen()
	{
		if(!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
		{
			echo "You don\'t have an access this page";
 			echo br(2); ?>
<a href="javascript:history.back()" class="back_link btn btn-small">Kembali</a>
<? 
		}

		$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));

		$uri_segment = 4;
		$data['offset'] = $this->uri->segment($uri_segment);

		$config['base_url'] = base_url().'jawaban/konsumen/index/';
		$config['total_rows'] = $this->jawaban_model->count_all();
		$config['per_page'] = 50;
		$config['next_link'] = '<li>Selanjutnya</li>';
		$config['prev_link'] = '<li>Sebelumnya</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
		$config['cur_tag_close'] = '</li>';

		$this->pagination->initialize($config);
		$data['paging'] = $this->pagination->create_links();

		$data['limit'] = $config['per_page'];

		$data['selected'] = $this->input->post('dimensi_id');
		
		// njrittt
		$dimensi = $this->input->post('dimensi_id');
		
		$data['jawa'] = $this->db->query("SELECT
											j.jawaban_id,j.created,	j.score,
											u.username,
											b.pertanyaan,
											b.faktor
											FROM
											jawaban AS j
											INNER JOIN banksoal AS b ON j.banksoal_id = b.banksoal_id
											INNER JOIN users AS u ON j.user_id = u.id
											INNER JOIN dimensi AS d ON b.dimensi_id = d.dimensi_id
											WHERE
											b.dimensi_id = '$dimensi'
											ORDER BY b.faktor ASC");
			
		// render template
		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
		$data['title'] 	 	= "Module Jawaban - Hasil Jawaban";
		$data['jawaban']    = "jawaban"; // Controller
		$data['view'] 		= "jawaban_view"; // View
		$data['module'] 	= "jawaban"; // Controller
			
		if($this->ion_auth->is_admin()) {
			echo Modules::run('template/admin',$data);
		}
		if($this->ion_auth->in_group('manajer')) {
			echo Modules::run('template/manajer', $data);
		}
	}
	/*
	 * Fungsi untuk menghapus setiap jawaban
	 * ---
	 * @access
	 * @param $jawaban_id dan $user_id
	 * 
	 */
	function delete($jawaban_id, $user_id)
	{	
		if(!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
		{
			echo "You don\'t have an access this page";
		 	echo br(2); ?>
		<a href="javascript:history.back()" class="back_link btn btn-small">Kembali</a>
		<? 
				}

		// Hapus data di tabel jawaban
		// $this->db->delete('jawaban', $data);
		$this->jawaban_model->delete($jawaban_id);
		// Update data user terhapus jawaban di tabel users
		$this->db->set('jawaban','jawaban-1', FALSE)
				 ->where('id', $user_id)
				 ->update('users');
	}
	
	/*
	 * Fungsi menampilkan hasil jawaban dari soal yang terjawab oleh user/ konsumen
	 * ---
	 * @access
	 * @param
	 *  
	 */
	function soal()
	{
		$id = $this->session->userdata('user_id');
		
		// paging
		$this->load->library('pagination');
		$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
		
		$uri_segment = 4;
		$data['offset'] = $this->uri->segment($uri_segment);
		
		$config['base_url'] = base_url().'jawaban/soal/index';
		$config['total_rows'] = $this->jawaban_model->count_all();
		$config['per_page'] = 5;
		$config['next_link'] = '<li>Selanjutnya</li>';
		$config['prev_link'] = '<li>Sebelumnya</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
		$config['cur_tag_close'] = '</li>';
		
		$this->pagination->initialize($config);
		$data['paging'] = $this->pagination->create_links();
		
		$data['limit'] = $config['per_page'];
		
		// Ambil dengan Faktor dirasakan
		$data['dirasakan'] = $this->db->query("SELECT
				s.pertanyaan,s.faktor,j.score,u.username,u.id,j.jawaban_id
				FROM  jawaban AS j
				INNER JOIN banksoal AS s ON j.banksoal_id = s.banksoal_id
				INNER JOIN users AS u ON j.user_id = u.id
				WHERE u.id = $id AND s.faktor = 'dirasakan'
				GROUP BY j.jawaban_id
				ORDER BY u.username ASC
				")->result();
		
		// Ambil dengan Faktor diharapakan
		$data['diharapkan'] = $this->db->query("SELECT
				s.pertanyaan,s.faktor,j.score,u.username,u.id,j.jawaban_id
				FROM  jawaban AS j
				INNER JOIN banksoal AS s ON j.banksoal_id = s.banksoal_id
				INNER JOIN users AS u ON j.user_id = u.id
				WHERE u.id = $id AND s.faktor = 'diharapkan'
				GROUP BY j.jawaban_id
				ORDER BY u.username ASC
				")->result();
		
		// render template
		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
		$data['title'] 	 	= "Module Jawaban - Hasil Jawaban Konsumen";
		$data['jawaban']    = "jawaban"; // Controller
		$data['view'] 		= "hasil_konsumen"; // View
		$data['module'] 	= "jawaban"; // Controller
		
		echo Modules::run('template/konsumen',$data);

	}
	
	public function detail($jawaban_id = null)
	{
		
	}
}


/* End of File: jawaban.php */
/* Location: ../www/modules/jawaban.php */