<div class="row-fluid">
	<div class="span12">
		<h3 class="heading">
			Report hasil jawaban untuk :
			<?php echo strtoupper($this->session->userdata('username'));?>
		</h3>
		<div class="tabbable tabs-left">
			<ul class="nav nav-tabs">
				<li class="active"><a href="#tab_l1" data-toggle="tab">Dirasakan</a>
				</li>
				<li><a href="#tab_l2" data-toggle="tab">Diharapkan</a>
				</li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane active" id="tab_l1">
					<p>
					<div class="span12">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>No</th>
									<th>Pertanyaan</th>
									<th>Nilai</th>
									<th>Fuzzy</th>
								</tr>
							</thead>
							<?php $no = 0 + $offset;?>
							<?php foreach ($dirasakan as $rasa): ?>
							<tbody>
								<tr>
									<td><?php echo ++$no;?></td>
									<td><?php echo $rasa->pertanyaan;?></td>
									<td><?php echo $rasa->score;?></td>
									<td>Fuzzy</td>
								</tr>
							</tbody>
							<?php endforeach; ?>
						</table>
					</div>
					</p>
				</div>
				<div class="tab-pane" id="tab_l2">
					<p>
					<div class="span12">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>No</th>
									<th>Pertanyaan</th>
									<th>Nilai</th>
									<th>Fuzzy</th>
								</tr>
							</thead>
							<?php $no = 0 + $offset;?>
							<?php foreach ($diharapkan as $harap): ?>
							<tbody>
								<tr>
									<td><?php echo ++$no;?></td>
									<td><?php echo $harap->pertanyaan;?></td>
									<td><?php echo $harap->score;?></td>
									<td>Fuzzy</td>
								</tr>
							</tbody>
							<?php endforeach; ?>
						</table>
					</div>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
