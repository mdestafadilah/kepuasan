
<div class="row-fluid">
	<div class="span12">
		<h3 class="heading">Pilihan Query "Dan"</h3>
		<div class="row-fluid sepH_c">
			<div class="span3">
				<p>
					<span class="label label-gebo"><a href="#" class="pop_over"
						data-content="Reability - dimensi kehandalan"
						data-original-title="Dimensi Kehandalan" data-placement="right">Dimensi
							Kehandalan</a> </span>
				</p>

				<select name="dimensi" id="chosen_a"
					data-placeholder="Choose a Country..." class="chzn_a">
					<option value=""></option>
					<option value="DZ">Algeria</option>
					<option value="AO">Angola</option>
				</select>
				<p>
					<span class="label label-gebo"><a href="#" class="pop_over"
						data-content="Reability - dimensi kehandalan"
						data-original-title="Dimensi Kehandalan" data-placement="right">Dimensi
							Kehandalan</a> </span>
				</p>

				<select name="dimensi" id="chosen_a"
					data-placeholder="Choose a Country..." class="chzn_a">
					<option value=""></option>
					<option value="DZ">Algeria</option>
					<option value="AO">Angola</option>
				</select>
				<p>
					<span class="label label-gebo"><a href="#" class="pop_over"
						data-content="Reability - dimensi kehandalan"
						data-original-title="Dimensi Kehandalan" data-placement="right">Dimensi
							Kehandalan</a> </span>
				</p>

				<select name="dimensi" id="chosen_a"
					data-placeholder="Choose a Country..." class="chzn_a">
					<option value=""></option>
					<option value="DZ">Algeria</option>
					<option value="AO">Angola</option>
				</select>
				<p>
					<span class="label label-gebo"><a href="#" class="pop_over"
						data-content="Reability - dimensi kehandalan"
						data-original-title="Dimensi Kehandalan" data-placement="right">Dimensi
							Kehandalan</a> </span>
				</p>

				<select name="dimensi" id="chosen_a"
					data-placeholder="Choose a Country..." class="chzn_a">
					<option value=""></option>
					<option value="DZ">Algeria</option>
					<option value="AO">Angola</option>
				</select>
				<p>
					<span class="label label-gebo"><a href="#" class="pop_over"
						data-content="Reability - dimensi kehandalan"
						data-original-title="Dimensi Kehandalan" data-placement="right">Dimensi
							Kehandalan</a> </span>
				</p>

				<select name="dimensi" id="chosen_a"
					data-placeholder="Choose a Country..." class="chzn_a">
					<option value=""></option>
					<option value="DZ">Algeria</option>
					<option value="AO">Angola</option>
				</select>
			</div>
			<div class="span9">
				<table class="table">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama Konsumen</th>
							<th>Pertanyaan</th>
							<th>Dimensi</th>
							<th>Kecewa</th>
							<th>Biasa</th>
							<th>Puas</th>
							<th>Fire Strength</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>134</td>
							<td>Summer Throssell</td>
							<td>summert@example.com</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
						</tr>
						<tr>
							<td>135</td>
							<td>Anthony Pound</td>
							<td>anthonyp@example.com</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
						</tr>
						<tr>
							<td>136</td>
							<td>Erin Church</td>
							<td>erinc@example.com</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
						</tr>
						<tr>
							<td>137</td>
							<td>Declan Pamphlett</td>
							<td>declanp@example.com</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
							<td>Ok</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row-fluid">
	<a href="<?php echo site_url('jawaban/query/dan');?>"
		class="btn btn-inverse"> Cari</a>
</div>
