<div class="row-fluid">
	<div class="span12">
		<h3 class="heading">Penilaian Pelanggan</h3>
		<div class="tabbable tabs-left">
			<ul class="nav nav-tabs">
				<li class="active"><a href="#tab_l1" data-toggle="tab">Dirasakan</a></li>
				<li><a href="#tab_l2" data-toggle="tab">Diharapkan</a></li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane active" id="tab_l1">
					<p>Content yang dirasakan!!</p>
				</div>
				<div class="tab-pane" id="tab_l2">
					<p>Content yang diharapkan!!</p>
				</div>
			</div>
		</div>
	</div>
</div>
