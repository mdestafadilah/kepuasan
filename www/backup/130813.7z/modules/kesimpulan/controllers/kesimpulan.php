<?php
/***************************************************************************************
 *                       			kesimpulan.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	kesimpulan.php
 *      Created:   		2013 - 15.37.07 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Kesimpulan extends MX_Controller {
 	function __construct(){
 		parent::__construct();
 	}
 	
 	function index()
 	{
 		echo 'yes';
 	}
 }
 
 
 /* End of File: kesimpulan.php */
/* Location: ../www/modules/kesimpulan.php */ 