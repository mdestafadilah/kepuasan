<?php
/***************************************************************************************
 *                       			aturan_moel.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	aturan_moel.php
 *      Created:   		2013 - 10.21.44 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 class Aturan_model extends MY_Model
 {
 	
 }
 
 /* End of File: aturan_moel.php */
/* Location: ../www/modules/aturan_moel.php */ 