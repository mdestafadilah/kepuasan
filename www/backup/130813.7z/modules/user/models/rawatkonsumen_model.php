<?php
/***************************************************************************************
 *                       			rawat_konsumen.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	rawat_konsumen.php
 *      Created:   		2013 - 22.11.29 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Rawatkonsumen_model extends MY_Model
 {
 	public $_table = "rawatkonsumen";
 	public $primary_key = "id";
 	
 	protected $belongs_to = array( 'konsumen', 'perawat' );
 	protected $has_many = array();
 }
 
 
 /* End of File: rawat_konsumen.php */
/* Location: ../www/modules/rawat_konsumen.php */ 