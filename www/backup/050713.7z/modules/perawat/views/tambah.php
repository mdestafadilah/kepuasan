<?php
/***************************************************************************************
 *                       			tambah.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	tambah.php
 *      Created:   		2013 - 06.14.21 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 
 
 
 /* End of File: tambah.php */
/* Location: ../www/modules/tambah.php */ 