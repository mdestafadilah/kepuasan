<?php
/**
 * File: noname.php
 * Short description for file
 *
 * Long description for file (if any)...
 *
 * LICENSE: Some license information
 *
 * @date       17-07-2013 12:45
 * @category   AksiIDE
 * @package    AksiIDE
 * @subpackage
 * @copyright  Copyright (c) 2013-endless AksiIDE
 * @license
 * @version    $version$
 * @link       http://aksiide.com
 * @since
 */

class Query extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		
		
		
		
		// Template
		$data['welcome'] = ucfirst($this->session->userdata('email'));
		$data['title']  = "Module Fuzzy Tahani - Pilih Query Fuzzy Standard";
		$data['jawaban']  = "query"; // Controller
		$data['view']   = "fuzzy_pilihan"; // View
		$data['module'] = "jawaban"; // Controller
		
		echo Modules::run('template/manajer',$data);
		
	}

	function DAN()
	{
		 // Rumus: min(sA[x], sB[x])
		 
		
		
		// Template
		$data['welcome'] = ucfirst($this->session->userdata('email'));
		$data['title']  = "Module Fuzzy Tahani - Pilih Dan Query";
		$data['jawaban']  = "query"; // Controller
		$data['view']   = "fuzzy_dan"; // View
		$data['module'] = "jawaban"; // Controller
		
		echo Modules::run('template/manajer',$data);
	}
	
	function ATAU()
	{
		// Rumus: max(sA[x], sB[x])
		
		
		// Template
		$data['welcome'] = ucfirst($this->session->userdata('email'));
		$data['title']  = "Module Fuzzy Tahani - Pilih Atau Query";
		$data['jawaban']  = "query"; // Controller
		$data['view']   = "fuzzy_atau"; // View
		$data['module'] = "jawaban"; // Controller
		
		echo Modules::run('template/manajer',$data);
	}
}


