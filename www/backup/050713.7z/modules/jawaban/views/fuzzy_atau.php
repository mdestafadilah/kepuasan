
<div class="heading clearfix">
	<h3 class="pull-left">Pilihan Query "Atau"</h3>

</div>

<div class="formSep">
	<div class="row-fluid">
		<div class="span6">

			<p>
				<span class="label label-gebo"><a href="#" class="pop_over" 
						data-content="Reability - dimensi kehandalan" 
						data-original-title="Dimensi Kehandalan" 
						data-placement="right">Dimensi Kehandalan</a></span>
			</p>
			
			<select name="dimensi" id="chosen_a"
				data-placeholder="Choose a Country..." class="chzn_a">
				<option value=""></option>
				<option value="DZ">Algeria</option>
				<option value="AO">Angola</option>
			</select>
			<p>
				<span class="label label-gebo"><a href="#" class="pop_over" 
						data-content="Reability - dimensi kehandalan" 
						data-original-title="Dimensi Kehandalan" 
						data-placement="right">Dimensi Kehandalan</a></span>						</p>

			<select name="dimensi" id="chosen_a"
				data-placeholder="Choose a Country..." class="chzn_a">
				<option value=""></option>
				<option value="DZ">Algeria</option>
				<option value="AO">Angola</option>
			</select>
			<p>
				<span class="label label-gebo"><a href="#" class="pop_over" 
						data-content="Reability - dimensi kehandalan" 
						data-original-title="Dimensi Kehandalan" 
						data-placement="right">Dimensi Kehandalan</a></span>						</p>

			<select name="dimensi" id="chosen_a"
				data-placeholder="Choose a Country..." class="chzn_a">
				<option value=""></option>
				<option value="DZ">Algeria</option>
				<option value="AO">Angola</option>
			</select>
			<p>
				<span class="label label-gebo"><a href="#" class="pop_over" 
						data-content="Reability - dimensi kehandalan" 
						data-original-title="Dimensi Kehandalan" 
						data-placement="right">Dimensi Kehandalan</a></span>						</p>

			<select name="dimensi" id="chosen_a"
				data-placeholder="Choose a Country..." class="chzn_a">
				<option value=""></option>
				<option value="DZ">Algeria</option>
				<option value="AO">Angola</option>
			</select>
			<p>
				<span class="label label-gebo"><a href="#" class="pop_over" 
						data-content="Reability - dimensi kehandalan" 
						data-original-title="Dimensi Kehandalan" 
						data-placement="right">Dimensi Kehandalan</a></span>			</p>

			<select name="dimensi" id="chosen_a"
				data-placeholder="Choose a Country..." class="chzn_a">
				<option value=""></option>
				<option value="DZ">Algeria</option>
				<option value="AO">Angola</option>
			</select>
		</div>
	</div>
</div>
<div class="row-fluid">
	<a href="<?php echo site_url('jawaban/query/atau');?>" class="btn btn-inverse"> Cari</a>
</div>
