
<div class="heading clearfix">
	<h3 class="pull-left">Pilih Query Fuzzy Tahani</h3>

</div>
<table>
	<p>
		<a href="<?php echo site_url('jawaban/query/dan');?>"
			class="btn btn-inverse"><i class="splashy-zoom"></i> Query "DAN" </a>
	
		<a href="<?php echo site_url('jawaban/query/atau');?>"
			class="btn btn-inverse"><i class="splashy-zoom"></i> Query "OR" </a>
	</p>
</table>
