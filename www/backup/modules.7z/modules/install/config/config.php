<?php
/***************************************************************************************
 *                       			config.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	config.php
 *      Created:   		2013 - 20.50.34 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/

	$config_site_name		= "Egypt CMS By Bleezeboy";
	
	$db_hostname			= "localhost";
	$db_database			= "egypt";
	$db_username			= "root";
	$db_password			= "";
	$db_dbdriver			= "mysql";

 /* End of File: config.php */
/* Location: ../www/modules/config.php */ 