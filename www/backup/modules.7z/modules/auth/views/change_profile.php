<?php echo $message;?>
<?php 
	echo form_open("auth/change_profile");
?>
<fieldset>
		<p class="f_legend">Edit Pengguna</p>
		<div class="control-group">
			<label class="control-label">Level: </label>
			<div class="controls">
			<?php
			foreach ($user->groups as $group):
				echo "<a href=\"#\" class=\"btn disabled\">".ucfirst($group->name)."</a>";
			endforeach;				
			?>
		</div>
		<div class="control-group">
			<label class="control-label">Username: </label>
			<div class="controls">
			<?php $u = array(
						'type' => 'text',
						'name' => 'username',
						'class'=> 'span4',
						'id' => 'username',	
						'value' => $profile->username,
					);
			?>
				<?= form_input($u);?>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label">Email: </label>
			<div class="controls">
			<?php
				$e = array(
						'type' => 'text',
						'name' => 'email',
						'class'=> 'span4',
						'id' => 'email',
						'value' => $profile->email,
					);
			?>
			<?= form_input($e);?>
			</div>
		</div>
	  		<?php echo form_hidden(array('id'=>$profile->id)); ?>
		<br />
		<div class="controls">
			<button type="submit" class="btn btn-inverse" id="sticky_b"><i class="splashy-check"></i> Simpan </button> | 
			<a href="<?=site_url('user');?>" class="btn">Cancel</a>
		</div>
			
</fieldset>
<?php echo form_close(); ?>
