<div class="heading clearfix">
	<h3 class="pull-left">Daftar Pertanyaan</h3>
	<span class="pull-right label label-important">NOTIF PELANGGAN LAGI
		ONLINE</span>
</div>
<div>

<?php echo $paging; ?>
	