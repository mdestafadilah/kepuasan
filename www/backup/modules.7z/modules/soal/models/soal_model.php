<?php
/***************************************************************************************
 *                       			soal_model.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	soal_model.php
 *      Created:   		2013 - 09.57.52 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Soal_model extends MY_Model
 {
 	public $_table = 'banksoal';
 	public $primary_key = 'banksoal_id';
 	
 	
 	
 }
 
 
 /* End of File: soal_model.php */
/* Location: ../www/modules/soal_model.php */ 