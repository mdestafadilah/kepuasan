<?php 
	echo form_open_multipart('perawat/update_profile','class = "form-horizontal well"');
?>
<?php  ?>
<fieldset>
	<div class="formSep">
		<p>
			<span class="label label-inverse">Ijasah</span>
		</p>
		<div class="row-fluid">
			<div class="span4">
				<input type="file" name="uni_file" id="uni_file" class="uni_style" />
			</div>
		</div>
		<p>
			<span class="label label-inverse">Foto</span>
		</p>
		<div class="row-fluid">
			<div class="span4">
				<input type="file" name="uni_file" id="uni_file" class="uni_style" />
			</div>
		</div>
	</div>
	<?php echo form_hidden($user_id);?>
	<?php echo form_submit();?>
</fieldset>
<?php echo form_close();?>

