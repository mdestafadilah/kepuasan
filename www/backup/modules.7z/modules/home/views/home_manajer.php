<div class="row-fluid">
<div class="span12">
	<h3 class="heading">Hak Manajer</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/edit.png')">
				Soal</a></li>
			<li><a href="<?=site_url('perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				<span class="label label-info"><?php echo $total_perawat;?></span> Perawat</a></li>
							<li><a href="<?=site_url('pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				<span class="label label-info"><?php echo $total_konsumen;?></span>Konsumen</a></li>
						</ul>
	</div>
	
	<h3 class="heading">Grafik</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/edit.png')">
				Soal</a></li>
			<li><a href="<?=site_url('perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Perawat</a></li>
			<li><a href="<?=site_url('pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Konsumen</a></li>
		</ul>
	</div>
</div>
</div>