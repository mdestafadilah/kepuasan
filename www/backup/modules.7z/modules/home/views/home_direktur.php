<div class="row-fluid">
<div class="span12">
	<h3 class="heading">Hak Direktur</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Perawat</a></li>
			<li><a href="<?=site_url('pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Konsumen</a></li>
			<li><a href="<?=site_url('soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/briefcase.png')">
				Soal</a></li>
		</ul>
	</div>
</div>
</div>
<div class="row-fluid">
	<div class="span5">
		<h3 class="heading">Presentase Jumlah Perawat</h3>
		<?php echo $charts; ?>		
		</div>
	
	<div class="span7">
	<h3 class="heading">Presentase Jumlah Konsumen</h3>
		here some graphik
	</div>
</div>
<div class="row-fluid">
	<div class="span5">
		<h3 class="heading">Presentase Jumlah Perawat</h3>
		here some graphik
	</div>
	
	<div class="span7">
	<h3 class="heading">Presentase Jumlah Konsumen</h3>
		here some graphik
	</div>
</div>
<div class="row-fluid">
	<div class="span5">
		<h3 class="heading">Presentase Jumlah Perawat</h3>
		here some graphik
	</div>
	
	<div class="span7">
	<h3 class="heading">Presentase Jumlah Konsumen</h3>
		here some graphik
	</div>
</div>
<div class="row-fluid">
	<div class="span5">
		<h3 class="heading">Presentase Jumlah Perawat</h3>
		here some graphik
	</div>
	
	<div class="span7">
	<h3 class="heading">Presentase Jumlah Konsumen</h3>
		here some graphik
	</div>
</div>