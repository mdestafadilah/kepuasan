<?php
/***************************************************************************************
 *                       			jawaban.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	jawaban.php
 *      Created:   		2013 - 11.23.47 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Jawaban extends MX_Controller
 {
 	function __construct() {
 		parent::__construct();
 		/* IONAuth */
 		
 	}
 	
 	function index()
 	{
 		
 	}
 	
 	function _manage()
 	{
 		
 	}
 	
 	function edit()
 	{
 		
 	}
 	
 	
 }
 
 
 /* End of File: jawaban.php */
/* Location: ../www/modules/jawaban.php */ 