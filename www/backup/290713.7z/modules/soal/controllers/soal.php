<?php
/***************************************************************************************
 *                       			soal.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	soal.php
 *      Created:   		2013 - 18.22.30 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Soal extends MX_Controller 
 {
 	function __construct() {
 		parent::__construct();
 		$this->load->library(array('ion_auth','session','form_validation'));
 		$this->load->helper('url');
 		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
 		// load some model
 		$this->load->model('soal_model');
 		$this->load->model('jawaban/jawaban_model');
 		$this->load->model('user/user_model');
 		$this->load->model('dimensi/dimensi_model');
 		// Enable Profiler
 		$this->output->enable_profiler(TRUE);
 	}
 	
 	function debuk()
 	{
 		
 		dump($data['soal1']);
 		dump($this->db->last_query());
 		exit;
 	}
 	
 	function index() 
 	{
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group(array('manajer','direktur')))
 		{
 			$this->_manage();
 		}
 		elseif ($this->ion_auth->is_admin() || $this->ion_auth->in_group(array('konsumen')))
 		{
 			$this->tampil();
 		}
 		else
 		{
 		echo 'You not have access';
 		echo br(2);
 		echo anchor('auth/login','Kembali');
 		}
 	}
 	
 	function _manage()
 	{
 			// paging
 			$this->load->library('pagination');
 			$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
 			
 			$uri_segment = 3	;
 			$data['offset'] = $this->uri->segment($uri_segment);
 			
 			$config['base_url'] = base_url().'soal/index/';
 			$config['total_rows'] = $this->soal_model->count_all();
 			$config['per_page'] = 20;
 			$config['next_link'] = '<li>Selanjutnya</li>';
 			$config['prev_link'] = '<li>Sebelumnya</li>';
 			$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
 			$config['cur_tag_close'] = '</li>';
 			
 			$this->pagination->initialize($config);
 			$data['paging'] = $this->pagination->create_links();
 			
 			$data['limit'] = $config['per_page'];
 			
 			// all soal as object as object :)
 			$data['results'] = $this->soal_model
 										->with('dimensi')
 										->limit($data['limit'], $data['offset'])
 										->get_all();
			
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] 	= "Modul Soal - Daftar Soal";
 			$data['module'] = "soal"; // module
 			$data['soal'] 	= "soal"; // controller
 			$data['view'] 	= "display"; // view
 		
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 			if($this->ion_auth->in_group('direktur')) {
 				echo Modules::run('template/direktur', $data);
 			}
 	}
 	
 	function add()
 	{
 		if (!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
 		{
 			echo 'You don\'t have an access';
 			echo br(2);
 			echo anchor('auth/login', 'Login');
 		}
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 			$this->form_validation->set_rules('pertanyaan', 'Soal', 'required');
 			$this->form_validation->set_rules('faktor', 'Faktor', 'required');
 			$this->form_validation->set_rules('dimensi', 'Dimensi', 'required');
 			$this->form_validation->set_rules('publish', 'Status', 'required');
 		}
 		
 		if ($this->form_validation->run() == true)
 		{
 			$data = array(
 				'pertanyaan' => $this->input->post('pertanyaan'),
 				'faktor' => $this->input->post('faktor'),
 				'dimensi_id' => $this->input->post('dimensi'),
 				'publish' => $this->input->post('publish'),
 				);
 		}
 		
 		if ($this->form_validation->run() == true
 				&& $this->soal_model->insert($data))
 		{
 			//dump($_POST);exit;
 			$this->session->set_flashdata('message', 'Soal Berhasil Ditambahkan');
 			redirect('soal/index','refresh');
 		}
 		else
 		{
 			
 			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
 			
 			$data['pertanyaan'] = array(
				'name'  => 'pertanyaan',
				'id'    => 'pertanyaan',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('pertanyaan'),
			);
 			$data['faktor'] = array(
 					'name'  => 'faktor',
 					'id'    => 'faktor',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('faktor'),
 			);
 			/* $data['dimensi'] = array(
 					'name'  => 'dimensi_id',
 					'id'    => 'dimensi_id',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('dimensi_id'),
 			); */
 			$data['publish'] = array(
 					'name'  => 'publish',
 					'id'    => 'publish',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('publish'),
 			);
		
 			// render template
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] = "Modul Soal - Tambah Data Soal";
 			$data['module'] = "soal"; // module
 			$data['soal'] = "soal"; // controller
 			$data['view'] = "soal_form"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 			
 		}
 		
 	}
 	
 	function update($banksoal_id)
 	{
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 		
 			$soal = $this->soal_model->get($banksoal_id); // an object of soal
 			$dimensi = $this->dimensi_model->as_array()->get_all(); // an array of dimensi
 			$soalDimensi = $this->soal_model
 									->with( 'dimensi' )
 									->get_all();
 			
 			$this->form_validation->set_rules('pertanyaan', 'Soal', 'required');
 			$this->form_validation->set_rules('faktor', 'Faktor', 'required');
 			$this->form_validation->set_rules('dimensi', 'Dimensi', 'required');
 			$this->form_validation->set_rules('publish', 'Status', 'required');
 			
 			// cek hasil ketik
 			if (isset($_POST) && !empty($_POST))
 			{
 				$data = array(
 						'pertanyaan' => $this->input->post('pertanyaan'),
 						'faktor' => $this->input->post('faktor'),
 						'dimensi_id' => $this->input->post('dimensi'),
 						'publish' => $this->input->post('publish'),
 						);
 			
	 			// jika bedul
	 			if ($this->form_validation->run() == TRUE && 
	 					$this->soal_model->update($soal->banksoal_id, $data))
	 			{
	 				$this->session->set_flashdata('message','Soal Berhasil terupdate');
	 				redirect('soal/index', 'refresh');
	 			}
 			}
 			
 			// Populate
 			$data['single'] = $soal;
 			$data['dimensi'] = $dimensi;
 			$data['soaldimensi'] = $soalDimensi;
 			
 			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
 			
 			$data['pertanyaan'] = array(
 					'name'  => 'pertanyaan',
 					'id'    => 'pertanyaan',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('pertanyaan', $soal->pertanyaan),
 					
 			);
 			$data['faktor'] = array(
 					'name'  => 'faktor',
 					'id'    => 'faktor',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('faktor', $soal->faktor),
 					
 					);
 			
 			$data['publish'] = array(
 					'name'  => 'publish',
 					'id'    => 'publish',
 					'type'  => 'text',
 					'value' => $this->form_validation->set_value('publish', $soal->publish),
 					
 			);
 			
 			// render template
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] = "Modul Soal - Ubah Data Soal";
 			$data['module'] = "soal"; // module
 			$data['soal'] = "soal"; // controller
 			$data['view'] = "soal_edit"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 			
 		}
 	}
 	
 	function delete($banksoal_id = null)
 	{
 		if (!$this->ion_auth->is_admin() && !$this->ion_auth->in_group('manajer'))
 		{
 			echo 'You don\'t have an access';
 			echo br(2);
 			echo anchor('soal/index','Kembali');
 		}
 		
 		/*
		 * Admin done
		 */
		elseif ($this->ion_auth->is_admin()
					&& $this->soal_model->delete($banksoal_id))
		{
			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Soal berhasil dihapus!</div>");
			redirect('soal/index');
		}
		/*
		 * Manajer done
		 */
		elseif ($this->ion_auth->in_group('manajer')
					&& $this->soal_model->delete($banksoal_id))
		{
			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Soal berhasil dihapus!</div>");
			
			redirect('soal/index');
		}
 	}
 	
 	function detail($banksoal_id)
 	{
 		echo "Still development";
 		echo br(2);
 		echo anchor('soal/index', 'Kembali');
 	}
 	
 	function _jawab()
 	{
 		// soal wajib di isi
 		$banksoal_id = (int) $banksoal_id;
 		$user_id 	 = $this->session->userdata('user_id');
 			
 			$this->form_validation->set_rules('pilihan', 'Pilihan', 'required');	
 			
 			if ($this->form_validation->run() == TRUE)
 			{
 				// populate data
 				$data = array(
 						'user_id' => $user_id,
 						'soal' => $this->soal_model->get_by(array("banksoal_id" => $banksoal_id)), // id soal
 						'banksoal_id' => $this->input->post('banksoal_id'),
 						'score' => $this->input->post('pilihan')
 						); 				
 			}
 		
 			
 	}
 	
 	/*
 	 * Original from: http://tutorialzine.com/2012/01/question-of-the-day-codeigniter-php-mysql/
 	* -----
 	* Fungsi menampilkan soal
 	* -----
 	* @access public
 	* @param $id
 	* @user Pelanggan
 	*/
 	
 	function tampil($banksoal_id = 1)
 	{
 		$banksoal_id = (int) $banksoal_id;
 		//$jawaban_id  = (int) $jawaban_id;
 		$user_id 	 = $this->session->userdata('user_id');
 		
 		// Cek keberadaan soal
 		$soal = $this->soal_model->as_array()->get_many_by(array('banksoal_id' => "$banksoal_id"));
 		if (empty($soal))
 		{
 			echo "Soal belum di Inputkan";
 		}

 		// SQL : SELECT MIN(`banksoal_id`) AS banksoal_id FROM (`banksoal`) WHERE `banksoal_id` > 1
 		// $res = $this->soal_model->as_array()->dirasakan_min($banksoal_id)->get_all();
 		$res = $this->db->select_min('banksoal_id')
				 		->where("banksoal_id > $banksoal_id")
				 		->get('banksoal')
				 		->result_array();
 		
 		// $pilihan = $this->form_validation->set_rules('pilihan', 'Pilihan','required');
 		$next = 0;
 		
 		if (isset($_POST) && !empty($res))
 		{
 			//looping
 			$next = $res[0]['banksoal_id'];
 			/* 
 			 * $pilihan = $this->input->post('pilihan');
 			
 			if ($this->form_validation->run() == TRUE 
 					&& $this->jawaban_model->insert($jawaban_id,$banksoal_id,$user_id,$pilihan))
 			{
 				$next = $res[0]['banksoal_id'];
 			} 
 			 */
 			
 		}
 		
 		//$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));

 		$data['soal1'] = $soal[0]['pertanyaan'];
 		$data['dim'] = $soal[0]['dimensi_id'];
 		$data['faktor'] = $soal[0]['faktor'];
 		$data['next'] = $next;
 		$data['total'] = $this->soal_model->count_all();
 		$data['banksoal_id'] = $banksoal_id;
 		
 		//$data['jawaban_id'] = $jawaban_id;
 		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 		$data['title'] 	 	= "Module Pelanggan - Tambah Pelanggan";
 		$data['soal']  		= "soal"; // Controller
 		$data['view'] 		= "papan_soal"; // View
 		$data['module'] 	= "soal"; // Controller
 		
 		echo Modules::run('template/konsumen', $data);
 		}

 	
 	/*
 	 * Original from: http://tutorialzine.com/2012/01/question-of-the-day-codeigniter-php-mysql/
 	 * -----
 	 * Fungsi menampilkan soal
 	 * -----
 	 * @access public
 	 * @param $id 
 	 * @user Pelanggan
 	 
 	function tampil($banksoal_id = 1)
 	{ 
 		// index
 		$prev = 0;
 		$next = 0;
 		
 		$aktifuser = $this->session->userdata('user_id');
 		
 		$this->input->post($aktifuser);
 		$this->input->post($banksoal_id);
 		
 		// Cek keberadaan soal
 		$t = $this->soal_model->as_array()->get_many_by(array('banksoal_id' => "$banksoal_id"));
 		if (empty($t))
 		{
 			echo "ok";
 		}
 		 		
 		
 		// SQL : SELECT MIN(`banksoal_id`) AS banksoal_id FROM (`banksoal`) WHERE `banksoal_id` > 1
 		 $res = $this->soal_model->as_array()->dirasakan_min()->get_all();
 		/* $res = $this->db->select_min('banksoal_id')
					 		->where("banksoal_id > $banksoal_id")
					 		->get('banksoal')
					 		->result_array(); 
 		 	
 		if (!empty($res)){
 			$next = $res[0]['banksoal_id']; //&& $this->do_jawaban();
 			if ($next == TRUE){
 				$this->_jawab();
 			}
 		}
 		
 		// SQL: SELECT MAX(`banksoal_id`) AS banksoal_id FROM (`banksoal`) WHERE `banksoal_id` < 1
 		$res = $this->soal_model->as_array()->dirasakan_max()->get_all();
 		/* $res = $this->db->select_max('banksoal_id')
			 				->where("banksoal_id < $banksoal_id")
			 				->get('banksoal')
			 				->result_array(); 
 		
 		if (!empty($res)){
 			$prev = $res[0]['banksoal_id'];
 		}
 		
 		/* 
 		$dimensi = array();
 		$dim = $this->dimensi_model->as_array()->get_many_by(array("dimensi_id" => "$dimensi_id");
 		$dim = $this->dimensi_model->as_array()->get_all();
 		foreach ($dim as $data)
 		{
 			$dimensi[$data['dimensi_id']] = $data['nama'];
 		}
 		echo $data['nama']; 
 		//
 		
 		//$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
 			
 			
 		// paging
 		$this->load->library('pagination');
 		$uri_segment = 4;
 		$data['offset'] = $this->uri->segment($uri_segment);
 			
 		$config['base_url'] = base_url().'soal/tampil/index/';
 		$config['total_rows'] = $this->soal_model->count_all();
 		$config['per_page'] = 1;
 		$config['next_link'] = '<li>Selanjutnya</li>';
 		$config['prev_link'] = '<li>Sebelumnya</li>';
 		$config['display_pages'] 	 = FALSE;
 		
 		$this->pagination->initialize($config);
 		$data['paging'] = $this->pagination->create_links();
 			
 		$data['limit'] = $config['per_page'];
 		$data['soal1'] = $this->soal_model
 									->as_array()
							 		->get_many_by(array('banksoal_id' => "$banksoal_id"));
 		
 		$data['soal1'] = $t[0]['pertanyaan'];
 		$data['dim'] = $t[0]['dimensi_id'];
 		$data['faktor'] = $t[0]['faktor'];
 		$data['next'] = $next;
 		$data['previous'] = $prev;
 		$data['total'] = $this->soal_model->count_all();
 		$data['banksoal_id'] = $banksoal_id;
 		
 		$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 		$data['title'] 	 	= "Module Pelanggan - Tambah Pelanggan";
 		$data['soal']  = "soal"; // Controller
 		$data['view'] 		= "papan_soal"; // View
 		$data['module'] 	= "soal"; // Controller
 		
 		
 		/* $data = array(
 				'soal1' => $t[0]['pertanyaan'],
 				'dim' => $t[0]['dimensi_id'],
 				'faktor' => $t[0]['faktor'],
 				'previous' => $prev,
 				'next' => $next,
 				'total' => $this->soal_model->count_all(),
 				'banksoal_id' => $banksoal_id,
 			
 				// render template as array
 				'welcome' => ucfirst($this->session->userdata('email')),
 				'title' => 'Module Pelanggan - Questioner',
 				'module' => 'soal',
 				'soal' => 'soal',
 				'view' => 'papan_soal',
 				); 
 		
 		echo Modules::run('template/konsumen', $data);
 	}
 	*/ 
 
 	function publish()
 	{
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 			// paging
 			$this->load->library('pagination');
 		
 			$uri_segment = 4;
 			$data['offset'] = $this->uri->segment($uri_segment);
 		
 		
 			$config['base_url'] = base_url().'soal/publish/index/';
 			$config['total_rows'] = $this->soal_model->count_all();
 			$config['per_page'] = 7;
 			$config['next_link'] = '<li>Selanjutnya</li>';
 			$config['prev_link'] = '<li>Sebelumnya</li>';
 			$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
 			$config['cur_tag_close'] = '</li>';
 		
 			$this->pagination->initialize($config);
 			$data['paging'] = $this->pagination->create_links();
 		
 			$data['limit'] = $config['per_page'];
 			
 			// Get aktif soal
 			$data['results'] = $this->soal_model
							 			->with('dimensi')
							 			->limit($data['limit'], $data['offset'])
 										->get_many_by(array('publish' => 1));
 			
 			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
 			
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] 	= "Modul Soal - Daftar Soal Yang Tampil";
 			$data['module'] = "soal"; // module
 			$data['soal'] 	= "soal"; // controller
 			$data['view'] 	= "display"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 				
 		}else{
 			echo 'You not have access';
 		}
 	}
 	
 	function unpublish()
 	{
 		if ($this->ion_auth->is_admin() || $this->ion_auth->in_group('manajer'))
 		{
 			// paging
 			$this->load->library('pagination');
 				
 			$uri_segment = 4;
 			$data['offset'] = $this->uri->segment($uri_segment);
 				
 				
 			$config['base_url'] = base_url().'soal/unpublish/index/';
 			$config['total_rows'] = $this->soal_model->count_all();
 			$config['per_page'] = 7;
 			$config['next_link'] = '<li>Selanjutnya</li>';
 			$config['prev_link'] = '<li>Sebelumnya</li>';
 			$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
 			$config['cur_tag_close'] = '</li>';
 				
 			$this->pagination->initialize($config);
 			$data['paging'] = $this->pagination->create_links();
 				
 			$data['limit'] = $config['per_page'];
 		
 			// Get aktif soal
 			$data['results'] = $this->soal_model
							 			->with('dimensi')
							 			->limit($data['limit'], $data['offset'])
							 			->get_many_by(array('publish' => 0));
 			
 			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
 			
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] 	= "Modul Soal - Daftar Soal Yang Unpublish";
 			$data['module'] = "soal"; // module
 			$data['soal'] 	= "soal"; // controller
 			$data['view'] 	= "display"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}
 				
 		}else{
 			echo 'You not have access';
 		}
 	}
 	
 	// still errur
 	function search()
 	{
 			$this->load->library('pagination');
 			$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'. validation_errors(). '</div>' : $this->session->flashdata('message'));
 			
 			$uri_segment = 4;
 			$data['offset'] = $this->uri->segment($uri_segment);
 			
 			$config['base_url'] = base_url().'soal/search/index/';
 			$config['total_rows'] = $this->soal_model->count_all();
 			$config['per_page'] = 20;
 			$config['next_link'] = '<li>Selanjutnya</li>';
 			$config['prev_link'] = '<li>Sebelumnya</li>';
 			$config['cur_tag_open'] = '<li class="active"><a href="#">..</a>';
 			$config['cur_tag_close'] = '</li>';
 			
 			$this->pagination->initialize($config);
 			$data['paging'] = $this->pagination->create_links();
 			
 			$data['limit'] = $config['per_page'];
 			 		
 			$data['hasil']  = $this->soal_model
							 		->searching()
							 		->limit($data['limit'], $data['offset'])
							 		->as_object() // optional, can use as_object?? really
							 		->get_by(array(
							 				'faktor' => $this->input->post('cari'),
							 		));
							 		
 		if ($data['hasil'] == null)
 		{
 			echo "Data yang dimasukan salah!";
 			echo br(2);
 			echo anchor('soal/index', 'kembali');
 		}
 		else
 		{
 			
 			dump($_POST); exit;
 			
 			// Render Template
 			$data['welcome'] = ucfirst($this->session->userdata('email'));
 			$data['title'] 	= "Modul Soal - Hasil Pencarian";
 			$data['module'] = "soal"; // module
 			$data['soal'] 	= "soal"; // controller
 			$data['view'] 	= "display"; // view
 				
 			if($this->ion_auth->is_admin()) {
 				echo Modules::run('template/admin',$data);
 			}
 			if($this->ion_auth->in_group('manajer')) {
 				echo Modules::run('template/manajer', $data);
 			}

 		}
 	}
 	/*
 	 * Do publish statuts
 	 * ----
 	 * inspired from heryCMS
 	 */
 	function do_publish($banksoal_id)
 	{
 		// cek harus manajer
 		if (!$this->ion_auth->logged_in() || !$this->ion_auth->in_group('manajer'))
 		{
 			echo "You don\'t have an access";
 			echo br(2);
 			echo anchor("soal/index", "Kembali");
 		}
 		else 
 		{
 			$this->db->where("banksoal_id", $banksoal_id);
 			$this->db->set("publish", 1);
 			$this->db->update("banksoal");
 			$this->session->set_flashdata('message', "Pertanyaan Sudah aktif");
 			redirect("soal/index");		
 		}
 	}
 	
 	/*
 	 * Do unpublish soal
 	 * -----
 	 */
 	function do_unpublish($banksoal_id)
 	{
 	// cek harus manajer
 		if (!$this->ion_auth->logged_in() || !$this->ion_auth->in_group('manajer'))
 		{
 			echo "You don\'t have an access";
 			echo br(2);
 			echo anchor("soal/index", "Kembali");
 		}
 		else 
 		{
 			$this->db->where("banksoal_id", $banksoal_id);
 			$this->db->set("publish", 0);
 			$this->db->update("banksoal");
 			$this->session->set_flashdata('message', "Pertanyaan Sudah tidak aktif");
 			redirect("soal/index");		
 		}
 	}
 }
 
 
 /* End of File: soal.php */
/* Location: ../www/modules/soal.php */ 