<div class="row-fluid">
		<h3 class="heading">Soal</h3>
			<div class="accordion-group">
				<div class="span12">
					<table class="table">
						<thead>
							<tr>
								<th>Total soal: <?php echo $total;?>
								<?php echo br(1);?>
								Dimensi: <?php echo $dim;?>
								dan Faktor : <?php echo $faktor;?>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo $soal1; ?>?</td>								
							</tr>
							<!-- <tr>
								<td>
									<label class="radio inline"> <input type="radio" value="40" name="pilihan" /> Kecewa </label> 
									<label class="radio inline"> <input type="radio" value="65" name="pilihan" /> Biasa </label> 
									<label class="radio inline"> <input type="radio" value="80" name="pilihan" /> Mengesankan</label> 
								 </td>
							</tr> -->
							<tr>
								<td>								
								<?php echo anchor("jawaban/add/$banksoal_id",'<i class="splashy-comment_question"></i> Jawab','class="btn btn-inverse"');?> atau
								<?php if($next) echo anchor("soal/tampil/$next",'<i class="splashy-arrow_state_blue_right"></i>Next','class="btn"');?>
									
								 </td>
							</tr>
						</tbody>						
					</table>
				</div>
			</div>
			<?php //if($previous) echo anchor("soal/tampil/$previous",'&laquo;','class="btn btn-primary left"');?>			
<!-- 		<div id="accordion1" class="accordion"> -->
<!-- 			<div class="accordion-group"> -->
<!-- 				<div class="accordion-heading"> -->
<!-- 					<a href="#collapseOne1" data-parent="#accordion1" -->
<!-- 						data-toggle="collapse" class="accordion-toggle">Total Soal: </a> -->
<!-- 				</div> -->
<!-- 				<div class="accordion-body collapse" id="collapseOne1"> -->
<!-- 					<div class="accordion-inner"> -->
<!-- 						<div class="span12"> -->
<!-- 							<label class="radio inline"> <input type="radio" value="option6" -->
<!-- 								name="gender" /> Male </label> <label class="radio inline"> <input -->
<!-- 								type="radio" value="option7" name="gender" /> Female </label> -->

							
<!-- 						</div> -->
						<!-- End span12 -->
<!-- 					</div> -->
					<!-- End Accordioan-inner -->
<!-- 				</div> -->
<!-- 			</div> -->
<!-- 		</div> -->
</div>
