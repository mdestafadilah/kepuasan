<div id="g_render"  class="left">
		<?php echo $charts; ?>
		
	</div>
