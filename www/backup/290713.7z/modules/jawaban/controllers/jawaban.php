<?php
/***************************************************************************************
 *                       			jawaban.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	jawaban.php
 *      Created:   		2013 - 11.23.47 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Jawaban extends MX_Controller
 {
 	function __construct() 
 	{
 		parent::__construct();
 		$this->load->library(array('ion_auth','session','form_validation'));
 		 		
 		$this->load->model('soal/soal_model');
 		
 		// Enable Profiler
 		$this->output->enable_profiler(TRUE);
 		
 	}
 	
 	function debuk($banksoal_id = 1)
 	{
 			$s = $this->soal_model->as_array()->get_by(array("banksoal_id" => $banksoal_id));
 			
 			echo "<pre>";
 			echo print_r($s);
 			echo "</pre>";
 			dump($this->db->last_query());
 			exit;
 	}
 	
 	function index()
 	{
 		echo "ok";
 	}
 	
 	function _manage()
 	{
 		
 	}
 	
 	function edit()
 	{
 		
 	}
 	
 	/*
 	 * Original from: http://tutorialzine.com/2012/01/question-of-the-day-codeigniter-php-mysql/
 	 * ----
 	 * Fungsi menambah jawaban
 	 * ----
 	 * @param $id
 	 * @access pelanggan
 	 */
 	function add($banksoal_id = -1)
 	{
 			
 		$soal = $this->soal_model->as_array()->get_many_by(array('banksoal_id' => "$banksoal_id"));
 		if (empty($soal))
 		{
 			echo "Soal belum di Inputkan";
 		}

 		// validasi inputan dropdon
 		$this->form_validation->set_rules('pilihan', 'Pilihan');

 		if ($this->form_validation->run() == true)
 		{
 			$sess_u = $this->session->userdata('user_id');
 			$soal_u = $soal[0]['banksoal_id'];
 			
 			//populate data
 			$data = array(
 					'user_id'		=> $this->input->post($sess_u),
 					'banksoal_id'   => $this->input->post($soal_u),
 					'score'			=> $this->input->post('pilihan'),
 			);
 		}

 		if ($this->form_validation->run() == true
 				&& $this->jawaban_model->insert($data))
 		{

 			$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Informasi berhasil ditambahkan!</div>");
 			redirect('soal/tampil/','refresh');
 		}
 		else
 		{
 			$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'.validation_errors().'</div>' : $this->session->flashdata('message'));

 			$data['pilihan'] = array(
 					'name' => 'pilihan',
 					'id' => 'pilihan',
 					'type' => 'text',
 					'class' => 'ttip_t',
 					'value' => $this->form_validation->set_value('pilihan'),
 			);

 			$data = array(
 					'soal'			=> $soal[0]['pertanyaan'],
 					'banksoal_id'	=> $soal[0]['banksoal_id']
 			);
 				
 			// set pesan
 			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
 				
 			// render template
 			$data['welcome'] 	= ucfirst($this->session->userdata('email'));
 			$data['title'] 	 	= "Module Jawaban - Tambah Jawaban";
 			$data['jawaban']    = "jawaban"; // Controller
 			$data['view'] 		= "jawaban_pilihan"; // View
 			$data['module'] 	= "jawaban"; // Controller

 			echo Modules::run('template/konsumen',$data);

 		}
 	}
 }
 
 
 /* End of File: jawaban.php */
/* Location: ../www/modules/jawaban.php */ 