<?php
/**
 * File: noname.php
 * Short description for file
 *
 * Long description for file (if any)...
 *
 * LICENSE: Some license information
 *
 * @date       17-07-2013 12:45
 * @category   AksiIDE
 * @package    AksiIDE
 * @subpackage
 * @copyright  Copyright (c) 2013-endless AksiIDE
 * @license
 * @version    $version$
 * @link       http://aksiide.com
 * @since
 */

class Query extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		echo "OK";
	}

	function DAN()
	{
		 // Rumus: min(sA[x], sB[x])
		 
		
	}
	
	function ATAU()
	{
		// Rumus: max(sA[x], sB[x])
	}
}


