<?php
/***************************************************************************************
 *                       			jawaban_model.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	jawaban_model.php
 *      Created:   		2013 - 08.48.20 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
 class Jawaban_model extends MY_Model
 {
 	public $_table = 'jawaban';
 	public $primary_key = "jawaban_id";
 	
 	public $belongs_to = array( 'banksoal' );
 	
  	public $has_many = array( 'users' );
 	
 }
 
 
 /* End of File: jawaban_model.php */
/* Location: ../www/modules/jawaban_model.php */ 
