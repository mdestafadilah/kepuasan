<?php
/***************************************************************************************
 *                       			group_model.php
***************************************************************************************
*      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
*      Website:    	http://www.twitter.com/emang_dasar
*
*      File:          	group_model.php
*      Created:   		2013 - 09.36.27 WIB
*      Copyright:  	(c) 2012 - desta
*                  	DON'T BE A DICK PUBLIC LICENSE
* 						Version 1, December 2009
*						Copyright (C) 2009 Philip Sturgeon
*
****************************************************************************************/
class Group_model extends MY_Model
{
	public $_table = 'groups';
	public $primarykey = 'id';
	
	
}


/* End of File: group_model.php */
/* Location: ../www/modules/group_model.php */