<?php
/***************************************************************************************
 *                       			konsumen.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	konsumen.php
 *      Created:   		2012 - 12.35.14 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 						Version 1, December 2009
 *						Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/
class Manajer extends MX_Controller
{
	private $groups = 'manajer';
	
	function __construct()
	{
		parent::__construct();
		$data = array();
		$this->load->library(array('ion_auth','session','form_validation'));
		$this->load->helper(array('url', 'form'));
		$this->load->model(array('pelanggan/pelanggan_model','user/rawatkonsumen_model','perawat/perawat_model'));

		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
		// Enable the output profiler so you can see the db queries run.
		$this->output->enable_profiler(TRUE);
	}
	
	function debuk()
	{
		/* 
		 * get perawat name id
		 * $query = "SELECT perawat.user_id,users.username
						FROM perawat 
						INNER JOIN users ON users.id = perawat.user_id
						ORDER BY username";
			$perawat_id = array();
			$perawat_id = $this->db->query($query)->result_array(); */

		$q = "  SELECT perawat_id, user_id AS `ID Login`, username, first_name
				FROM rawatkonsumen
				INNER JOIN konsumen ON konsumen.konsumen_id = rawatkonsumen.konsumen_id
				INNER JOIN users ON konsumen.user_id = users.id
			 ";
		//$data = $this->db->query($q)->result_array();
		
		
		$this->db->select('perawat_id, user_id AS \'ID Login\', username, first_name');
		$this->db->from('rawatkonsumen');
		$this->db->join('konsumen','konsumen.konsumen_id = rawatkonsumen.konsumen_id', 'inner');
		$this->db->join('users','konsumen.user_id = users.id', 'inner');
		
		$data = $this->db->get()->result_array();
		
		
		echo "<pre>";
		echo print_r($data);
		echo "</pre>";
		
		foreach ($data as $d)
		{
			echo $d['username'];
			echo br(2);
			echo $d['ID Login'];
		}
		dump($this->db->last_query());exit;
		
	}

	function index()
	{
		if ($this->ion_auth->logged_in() && $this->ion_auth->in_group($this->groups))
		{
			$data['total_perawat'] = $this->ion_auth->users('4')->num_rows();
			$data['total_konsumen'] = $this->ion_auth->users('3')->num_rows();
			
			// Buat Template
			$data['welcome'] = ucfirst($this->session->userdata('email'));
			$data['title'] 	 = "Welcome to Sistem";
			$data['manajer'] = "manajer"; // Controller
			$data['view'] 	 = "home_manajer"; // View
			$data['module']  = "home"; // Controller
				
			// Load Template->view(login)
			echo Modules::run('template/manajer',$data);
		}else{
			redirect('auth/index/', 'refresh');
		}
	}
	
	function profile()
	{
		if ($this->ion_auth->logged_in() && $this->ion_auth->in_group($this->groups))
		{
				
			// Buat Template
			$data['welcome'] = ucfirst($this->session->userdata('email'));
			$data['title'] 	 = "Profile Manajer";
			$data['manajer'] = "manajer"; // Controller
			$data['view'] 	 = "gen_manajer"; // View
			$data['module']  = "user"; // Controller
		
			// Load Template->view(login)
			echo Modules::run('template/manajer',$data);
		}else{
			redirect('auth/index/', 'refresh');
		}
	}
	//------------------------------------------------------------------------------------------------
	
	function rawat_konsumen()
	{
			// validasi inputan dropdon
			$this->form_validation->set_rules('perawat_id', 'Nama Perawat');
			$this->form_validation->set_rules('konsumen_id', 'Nama Konsumen');
			
			if ($this->form_validation->run() == true)
			{
				//populate data
				$data = array(
						'perawat_id'	=> $this->input->post('perawat_id'),
						'konsumen_id'   => $this->input->post('konsumen_id'),
						);
			}
			
			if ($this->form_validation->run() == true
					&& $this->rawatkonsumen_model->insert($data))
			{
				
				$this->session->set_flashdata('message', "'<div class=\"alert alert-success\"><a class=\"close\" data-dismiss=\"alert\">X</a>'Informasi berhasil ditambahkan!</div>");
				redirect('user/manajer/rawat_konsumen/','refresh');
			}
			else
			{
				$data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>'.validation_errors().'</div>' : $this->session->flashdata('message'));
				
				$data['konsumen_id'] = array(
						'name' => 'konsumen_id',
						'id' => 'konsumen_id',
						'type' => 'text',
						'class' => 'ttip_t',
						'value' => $this->form_validation->set_value('konsumen_id'),
				);
				
				$data['perawat_id'] = array(
						'name' => 'perawat_id',
						'id' => 'perawat_id',
						'type' => 'text',
						'class' => 'ttip_t',
						'value' => $this->form_validation->set_value('perawat_id'),
				);
								
				// Buat Template
				$data['welcome'] = ucfirst($this->session->userdata('email'));
				$data['title'] 	 = "Module Manajer - Update Rawat Konsumen";
				$data['manajer'] = "manajer"; // Controller
				$data['view'] 	 = "rawat_konsumen_view"; // View
				$data['module']  = "user"; // Controller
				
				// Load Template->view(login)
				echo Modules::run('template/manajer',$data);
			}
		}

	function list_rawat_konsumen()
	{
		 $data = $this->rawatkonsumen_model
		                    
                             ->get_all();
		 dump($this->db->last_query());
		 dump($data);exit;
		
	}
}
 
 
 /* End of File: konsumen.php */
/* Location: ../www/modules/konsumen.php */ 