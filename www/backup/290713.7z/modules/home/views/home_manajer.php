<div class="row-fluid">
<div class="span12">
	<h3 class="heading">Pengaturan Umum</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/edit.png')">
				Soal</a></li>
			<li><a href="<?=site_url('dimensi')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/add-item.png')">
				Dimensi</a></li>
			<li><a href="<?=site_url('perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				<span class="label label-info"><?php echo $total_perawat;?></span> Perawat</a></li>
			<li><a href="<?=site_url('pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				<span class="label label-info"><?php echo $total_konsumen;?></span>Konsumen</a></li>
			<li><a href="<?=site_url('user/manajer/list_rawat_konsumen')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/multi-agents.png')">
				Informasi</a></li>
						</ul>
	</div>
	
	<h3 class="heading">Pengaturan Kepuasan</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('grafik/soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/edit.png')">
				Soal</a></li>
			<li><a href="<?=site_url('grafik/perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Perawat</a></li>
			<li><a href="<?=site_url('grafik/pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Konsumen</a></li>
		</ul>
	</div>
	
	<h3 class="heading">Laporan Kepuasan</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('grafik/soal')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/bar-chart.png')">
				Soal</a></li>
			<li><a href="<?=site_url('grafik/perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/bar-chart.png')">
				Perawat</a></li>
			<li><a href="<?=site_url('grafik/pelanggan')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/bar-chart.png')">
				Konsumen</a></li>
		</ul>
	</div>
</div>
</div>