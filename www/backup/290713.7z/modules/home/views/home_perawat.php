<div class="row-fluid">
<div class="span12">
	<h3 class="heading">Hak Akses</h3>
	<div class="span12">
		<ul class="pull-left dshb_icoNav tac">
			<li><a href="<?=site_url('user/perawat/profile')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/agent.png')">
				Profile</a></li>
			<li><a href="<?=site_url('jawaban/hasil')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/next-item.png')">
				Hasil</a></li>
			<li><a href="<?=site_url('perawat')?>"
				style="background-image: url('<?=asset_url();?>img/gCons/chat-02.png')">
				Kesimpulan</a></li>
		</ul>
	</div>
</div>
</div>